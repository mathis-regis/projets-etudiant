/////////////////////////////////////////////////////
//
// Démineur
// DM "UED 131 - Programmation impérative" 2023-2024
// NOM         : REGIS
// Prénom      : Mathis
// N° étudiant : 20230161
//
// Collaboration avec :  personne
//
/////////////////////////////////////////////////////

//
// Initialisation de la fenêtre graphique
//
int cote;
int bandeau;
int colonnes = 30;
int lignes = 16;
///étape du jeu///
final  int INIT = 0;
final int STARTED = 1;
final int OVER = 2;
int etat = INIT;
///etat de bloc///
final int BLOC = 0;
final int EMPTY = 1;
final int FLAG = 2;
int etat_bloc = INIT;
///temp chrono///
int START;
int TIME;
PFont police;
/// temp affiché suite au game over///
int time_over;
///initialisation tableau contenant case du jeu///
int[][] paves = new int[lignes][colonnes];
///initialisation tableau contenant bombes///
boolean[][]bombes = new boolean[lignes][colonnes];
///initialisation tableau contenant le nombre de bombe a coté///
int[][]nb_bombes = new int[lignes][colonnes];
///mine a trouver///
int mine_restante = 100;
///variables contenant la position de la bombe quand on clique sur cette meme bombe///
int xbombe = -1;
int ybombe = -1;

void settings() {
  cote = 20;
  bandeau = 50;
  colonnes = 30;
  lignes = 16;
  size(600,370);
}

//
// Initialisation du programme
//
void setup() {
  init();
  int x = 0 ;
  int y = 0 ;
  for (int i= 0; i != 480; i++)
  {
    if (y > 29)
    {
      y = 0;
      x += 1;
    }
    drawBloc(x,y,0,0);
    paves[x][y] = BLOC;
    y += 1;
  }
}

//
// Initialisation du jeu
//
void init() {
  etat_bloc = BLOC;
  ///initialisation tableau a faux///
  int x = 0;
  int y = 0;
  for (int i= 0; i != 480; i++)
  {
    if (y > 29)
    {
      y = 0;
      x += 1;
    }
    bombes[x][y] = false;
    y += 1;
  }
///remplissage tableau bombe avec 100 bombes///
int ligne;
int colonne;
  for (int i = 0; i<100; i++)
  {
    ligne = round(random(lignes-1));
    colonne= round(random(colonnes-1));
    if (bombes[ligne][colonne] == false)
    {
      bombes[ligne][colonne]= true;
    }
    else
    {
      i--;
    }
  }
  ///remplisage tableau nb_bombe qui contient le nb de bombe a coté///
  x = 0;
  y = 0;
  int bombe_a_cote=0;
  for (int i= 0; i < 480; i++)
  {
    bombe_a_cote = 0;
    if (y > 29)
    {
      y = 0;
      x += 1;
    }
////vérification de bombe a coté////
//// cas normal, avec 0<x<15 et 0<y<29 ////
    if ((x>0 )& (y > 0))
    {
      if ((x < 15) & (y < 29))
      {
        if (bombes[x-1][y-1]) 
        { 
          bombe_a_cote += 1; 
        } 
        if (bombes[x][y-1]) 
        { 
          bombe_a_cote += 1; 
        } 
        if (bombes[x+1][y-1]) 
        { 
          bombe_a_cote += 1; 
        } 
      if (bombes[x-1][y]) 
        { 
          bombe_a_cote += 1; 
        } 
      if (bombes[x+1][y]) 
        { 
          bombe_a_cote += 1; 
        } 
      if (bombes[x-1][y+1]) 
        { 
          bombe_a_cote += 1; 
        } 
      if (bombes[x][y+1]) 
        { 
          bombe_a_cote += 1; 
        } 
      if (bombes[x+1][y+1]) 
        { 
          bombe_a_cote += 1; 
        }     
      }
    }
//// cas spécifiques ////
//// 1) x == 0 et y == 0  /////
    if ((x == 0)&(y == 0 ))
    {
      if (bombes[x][y+1])
      {
        bombe_a_cote += 1;
      }
      if(bombes[x+1][y])
      {
        bombe_a_cote += 1;
      }
      if(bombes[x+1][y+1])
      {
        bombe_a_cote+= 1;
      }
    }
//// 2) x == 0 et 0<y<29  ////
    if ((x == 0) & (y != 29) & (y != 0))
    {
      if (bombes[x][y-1])
      {
        bombe_a_cote+= 1;
      }
      if (bombes[x][y+1])
      {
        bombe_a_cote+= 1;
      }
      if (bombes[x+1][y-1])
      {
        bombe_a_cote+= 1;
      }
      if (bombes[x+1][y])
      {
        bombe_a_cote+= 1;
      }
      if (bombes[x+1][y+1])
      {
        bombe_a_cote+= 1;
      }
    }
//// 3) 0<x<15 , et y == 0 ////
    if ((x != 0) & (x != 15) & (y == 0))
    {
      if (bombes[x-1][y])
      {
        bombe_a_cote+= 1;
      }
      if (bombes[x-1][y+1])
      {
        bombe_a_cote+= 1;
      }
      if (bombes[x][y+1])
      {
        bombe_a_cote+= 1;
      }
      if (bombes[x+1][y])
      {
        bombe_a_cote+= 1;
      }
      if (bombes[x+1][y+1])
      {
        bombe_a_cote+= 1;
      }
    }
//// 4) x == 15 et y == 29 ////
    if ((x == 15) & (y == 29))
    {
      if (bombes[x-1][y-1])
      {
        bombe_a_cote += 1;
      }
      if(bombes[x-1][y])
      {
        bombe_a_cote += 1;
      }
      if(bombes[x][y-1])
      {
        bombe_a_cote+= 1;
      }
    }
//// 5) x == 15 et 0<y<29 ////
    if ((x == 15) & (y != 0) & (y != 29))
    {
      if (bombes[x-1][y-1])
      {
        bombe_a_cote+= 1;
      }
      if (bombes[x-1][y])
      {
        bombe_a_cote+= 1;
      }
      if (bombes[x-1][y+1])
      {
        bombe_a_cote+= 1;
      }
      if (bombes[x][y-1])
      {
        bombe_a_cote+= 1;
      }
      if (bombes[x][y+1])
      {
        bombe_a_cote+= 1;
      }
    }
//// 6) 0<x<15 et y == 29 ////
    if ((x != 0) & (x != 15) & (y == 29))
    {
      if (bombes[x-1][y-1])
      {
        bombe_a_cote+= 1;
      }
      if (bombes[x-1][y])
      {
        bombe_a_cote+= 1;
      }
      if (bombes[x][y-1])
      {
        bombe_a_cote+= 1;
      }
      if (bombes[x+1][y-1])
      {
        bombe_a_cote+= 1;
      }
      if (bombes[x+1][y])
      {
        bombe_a_cote+= 1;
      }
    }
//// 7) x == 15 et y == 0 ////x-1 y ,x-1 y+1 ,x y+1
    if ((x == 15) & (y == 0))
    {
      if (bombes[x-1][y])
      {
        bombe_a_cote += 1;
      }
      if(bombes[x-1][y+1])
      {
        bombe_a_cote += 1;
      }
      if(bombes[x][y+1])
      {
        bombe_a_cote+= 1;
      }
    }
//// 8) x == 0 et y == 29 ////x y-1, x+1 y-1 ,x+1 y
    if ((x == 0) & (y == 29))
    {
      if (bombes[x][y-1])
      {
        bombe_a_cote += 1;
      }
      if(bombes[x+1][y-1])
      {
        bombe_a_cote += 1;
      }
      if(bombes[x+1][y])
      {
        bombe_a_cote+= 1;
      }
    }
    nb_bombes[x][y] = bombe_a_cote;
    y += 1;
  }
}

//
// boucle de rendu
// - met à jour le temps écoulé depuis le début de la résolution
// - appelle la fonction d'affichage
//
void draw() 
{
  int x = 0;
  int y = 0;
  display();
  drawTime();
  drawScore();
  for (int i= 0; i != 480; i++)
  {
    if (y > 29)
    {
      y = 0;
      x += 1;
    }
    if ( (etat == INIT)||(etat == OVER))
    {
      paves[x][y] = BLOC;
    }
    if(paves[x][y] == FLAG)
    {
      drawBloc(x,y,0,0);
      drawFlag(x,y);
    }
    if(paves[x][y] == EMPTY)
    {
      drawEmpty(x,y);
      drawNbBombesACote(x,y);
    }
    if(paves[x][y] == BLOC)
    {
      drawBloc(x,y,0,0);
    }
    if (etat == OVER)
    {
      if (bombes[x][y])
      {
        drawBomb(x,y);
        mine_restante =100;
      }
    }
    y += 1;
  }
}

//
// calcule le nombre de bombes dans les 8 cases voisines
// (x, y) = coordonnées de la case
//
void voisins(int x, int y) {
}

//
// affiche un bloc
// (x, y) = coordonnées du bloc
// (w, h) = dimensions du bloc
//
void drawBloc(int x, int y, int w, int h) {
  pushMatrix();
  translate(0,bandeau);
  x = x*cote;
  y = y*cote;
  translate(y,x);
  //carré gris clair
  fill(150);
  rect(2,2,18,18);
  //carré gris foncé
  fill(125);
  rect(18,1,1,19);
  rect(19,0,1,20);
  rect(2,18,18,1);
  rect(0,19,20,1);
  popMatrix();
}

//
// affiche un drapeau dans la case
// (x, y) = coordonnées de la case
//
void drawFlag(int x, int y) {
  pushMatrix();
  translate(0,bandeau);
  x = x*cote;
  y = y*cote;
  translate(y,x);
  //base du drapeau
  fill(0);
  rect(4,15,13,2);
  rect(6,13,9,2);
  //le mat du drapeau
  rect(10,5,1,8);
  //le drapeau rouge
  fill(255,0,0);
  rect(9,5,1,5);
  rect(6,6,3,3);
  rect(4,7,2,1);
  popMatrix();
}

//
// affiche une bombe dans la case
// (x, y) = coordonnées de la case
//
void drawBomb(int x, int y) {
  pushMatrix();
  translate(0,bandeau);
  x = x*cote;
  y = y*cote;
  translate(y,x);
  //centre de la bombe (noire)
  fill(0);
  rect(8,6,5,9);
  rect(7,7,7,7);
  rect(6,8,9,5);
  //barre de la bombe (verticale,horizontale)
  rect(10,4,1,13);
  rect(4,10,13,1);
  //barre de la bombe penché 1
  rect(5,5,1,1);
  rect(6,6,1,1);
  rect(14,14,1,1);
  rect(15,15,1,1);
  //barre de la bombe penché 2
  rect(15,5,1,1);
  rect(14,6,1,1);
  rect(6,14,1,1);
  rect(5,15,1,1);
  //centre de la bombe (blanche)
  fill(255);
  rect(8,8,2,4);
  rect(7,9,4,2);
  popMatrix();
}
///
/// affiche une case vide 
void drawEmpty(int x,int y)
{
  pushMatrix();
  translate(0,bandeau);
  x = x*cote;
  y = y*cote;
  translate(y,x);
  fill(120);
  rect(0,0,20,20);
  popMatrix();
}

//
// affiche dans la case le nombre de mines
//  présentes dans les 8 cases voisines 
//
void drawNbBombesACote(int i, int j) 
{
  fill(0);
  police = createFont("mine-sweeper.ttf",10);
  textFont(police);
  int case_voisines = nb_bombes[i][j];
/// choix de la couleur du texte en fonction du nombre de bombes voisines ///
  if (case_voisines == 1)
  {
    fill(0,35,245);
  }
  if (case_voisines == 2)
  {
    fill(55,125,35);
  }
  if (case_voisines == 3)
  {
    fill(235,50,35);
  }
  if (case_voisines == 4)
  {
    fill(120,25,120);
  }
  if (case_voisines == 5)
  {
    fill(115,20,10);
  }
  if (case_voisines == 6)
  {
    fill(55,125,125);
  }
  if (case_voisines != 0)
  {
    text(case_voisines,(j*cote)+5,(i*cote)+65);
  }
}

//
// affiche le nombre de mines restant à localiser
//
void drawScore() 
{
  police = createFont("DSEG7Classic-Bold.ttf",32);
  fill(0);
  rect(6,5,80,40);
  fill(90,10,10);
  textFont(police);
  textSize(30);
  text(888,10,40);
  fill(255,0,0);
  if (START!=0)
  {
    if (mine_restante<10)
    {
      text("00"+mine_restante,10,40);
    }
    if ((mine_restante>=10)& (mine_restante<100))
    {
      text("0"+mine_restante,10,40);
    }
    if (mine_restante>=100)
    {
      text(mine_restante,10,40);
    }
  }
}

//
// affiche le temps écoulé depuis le début de la résolution
//
void drawTime() 
{
  TIME = (millis()-START)/1000;
  police = createFont("DSEG7Classic-Bold.ttf",32);
  fill(0);
  rect(500,5,80,40);
  fill(90,10,10);
  textFont(police);
  textSize(30);
  text(888,503,40);
  fill(255,0,0);
  if (etat == OVER)
  {
    if (time_over<10)
    {
      text("00"+time_over,503,40);
    }
    if ((time_over>=10)& (time_over<100))
    {
      text("0"+time_over,503,40);
    }
    if (time_over>=100)
    {
      text(time_over,503,40);
    }
  }
  if (START!=0)
  {
    if (TIME>999)
    {
      TIME = millis() - TIME;
    }
    if (TIME<10)
    {
      text("00"+TIME,503,40);
    }
    if ((TIME>=10)& (TIME<100))
    {
      text("0"+TIME,503,40);
    }
    if (TIME>=100)
    {
      text(TIME,503,40);
    }
  }
}

//
// dessine un smiley content au centre du bandeau
//
void drawHappyFace() 
{
  pushMatrix();
  translate(280,12);
  //tete
  fill(255,255,0);
  ellipse(10,10,20,20);
  //yeux
  fill(0);
  ellipse(5,7,2,2);
  ellipse(15,7,2,2);
  //bouche contente
  strokeWeight(2);
  noFill();
  arc(10,12,7,7,0.65,2.5);
  popMatrix();
  strokeWeight(1);
}

//
// dessine un smiley mécontent au centre du bandeau
//
void drawSadFace() 
{
  pushMatrix();
  translate(280,12);
  //tete
  fill(255,255,0);
  ellipse(10,10,20,20);
  //yeux
  fill(0);
  ellipse(5,7,2,2);
  ellipse(15,7,2,2);
  //bouche pas contente
  strokeWeight(2);
  noFill();
  arc(10,14,7,7,PI,2*PI);
  popMatrix();
  strokeWeight(1);
}

//
// affiche le démineur
//
void display() {
  background(192);
  fill(100);
  rect(0,50,600,320);
  if ((etat == INIT) || (etat == STARTED))
  {
    drawHappyFace();
    xbombe = -1;
    ybombe = -1;
  }
  if (etat == OVER)
  {
    drawSadFace();
  }
  if (xbombe >= 0)
  {
    drawBomb(xbombe,ybombe);
  }
}

//
// affiche le démineur quand on a perdu
// = on révèle l'emplacement des bombes
// et on affiche le smiley mécontent
//
void displayBombs(int x, int y) {
}

//
// calcule les blocs qui doivent être découverts
// = les blocs vides autour si (x, y) est vide
//
void decouvre(int x, int y) {
}

//
// calcule les blocs qui doivent être découverts
// = les blocs vides autour de la case (x, y) portant un numéro, 
// dont on a localisé tous les blocs voisins
//
void decouvre2(int x, int y) {
}

//
// met à jour le nombre de drapeaux voisins 
// qui ont été localisés et marqués
//
void updateNbDrapeaux(int x, int y) {
}

//
// gère les interactions souris
//
void mouseClicked() 
{
  /// variables contenant la position du bloc dans la grille ///
  int x_du_bloc = ((mouseY-50) / cote);
  int y_du_bloc = mouseX / cote;
  //etat du jeu//
  if ((mouseY >50) & (etat==INIT))
  {
    etat = STARTED;
    START = millis();
  }
  if ((mouseX>280)&(mouseX<300)&(mouseY>12)&(mouseY<32)&(etat==STARTED))
  {
    etat= INIT;
    init();
    START = 0;
  }
  if ((mouseX>280)&(mouseX<300)&(mouseY>12)&(mouseY<32)&(etat==OVER))
  {  
    etat = INIT;
    init();
  }
  if ((mouseX>0) & (mouseY > 50) & (mouseY<370) & (mouseX< 600))
  {
    if ((bombes[x_du_bloc][y_du_bloc])&&(etat==STARTED)&&(mouseButton == LEFT))
    { 
      paves[x_du_bloc][y_du_bloc] = EMPTY;
      xbombe = x_du_bloc;
      ybombe = y_du_bloc;
      etat = OVER;
      time_over = TIME;
      START = 0;
    }
  //etat du bloc//
  if ((paves[x_du_bloc][y_du_bloc] == BLOC)&&(mouseButton == LEFT))
  {
    paves[x_du_bloc][y_du_bloc] = EMPTY;
  }
  if ((paves[x_du_bloc][y_du_bloc] == BLOC)&&(mouseButton == RIGHT))
  {
    paves[x_du_bloc][y_du_bloc] = FLAG;
    mine_restante --;
  }
  else if ((paves[x_du_bloc][y_du_bloc] == FLAG)&&(mouseButton == RIGHT))
  {
    paves[x_du_bloc][y_du_bloc] = BLOC;
    mine_restante ++;
  }
 }
}
