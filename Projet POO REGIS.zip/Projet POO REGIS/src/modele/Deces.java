package modele;
import java.util.Date;
import java.io.Serializable;


public class Deces implements Serializable{

	//id de serialisation
	private static final long serialVersionUID = 1L;
    /**
     * Default constructor
     */
    public Deces() {
    }

    /**
     * 
     */
    private Date Date_décès;

	/// Association ///
	
	private Mairie mairie;
	private Citoyen citoyen;
	
	/// Constructeur simple///
	
	public Deces (Date d)
	{
		Date_décès = d;
	}
	
	/// Constructeur avancé ///
	
	public Deces(Date d, Mairie m, Citoyen c)
	{
		Date_décès = d;
		setMairie(m);
		setCitoyen(c);
	}
	
	/// Methode ///
	public void setMairie(Mairie m)
	{
		mairie = m;
	}
	public void setCitoyen(Citoyen c)
	{
		citoyen = c;
	}

	public Mairie getMairie()
	{
		return mairie;
	}
	public Citoyen getCitoyen()
	{
		return citoyen;
	}
	public Date getDateDeces()
	{
		return Date_décès;
	}
}