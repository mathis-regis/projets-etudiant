package modele;
import java.io.*;
import java.util.*;

/**
 * 
 */
public class Femme extends Citoyen {

	/// Association ///
	
	Vector <Marriage> listMarriage = new Vector <Marriage>();
	Vector <Naissance> listNaissance = new Vector <Naissance>();
	
	public Femme()
  {
    super();
  }
  /// Constructeur avancé ///
  public Femme(String nom, String prenom, Date dateNaissance, Mairie mairie)
  {
    super(nom,prenom,dateNaissance,false,mairie);
  }

	/// Methode ///
	
	public void addMarriage (Marriage m)
	{
		listMarriage.add(m);
	}
	public void addNaissance (Naissance n)
	{
		listNaissance.add(n);
	}

  public Vector <Marriage> getListMarriage()
	{
		return listMarriage ;
	}
	public Vector <Naissance> getListNaissance()
	{
		return listNaissance ;
	}

	public boolean estMarie()
	{
		if (getListMarriage().isEmpty())
		{
			return false;
		}
		else if (getListMarriage().lastElement().getDivorce() != null)
		{
			return false;
		}
		else
		{
			return true;
		}
	}
	public void setIdConjoint()
	{
		if (this.estMarie())
		{
			if (getListMarriage().lastElement().getCitoyen1().getIdCitoyen() == this.getIdCitoyen())
			{
				id_conjoint = getListMarriage().lastElement().getCitoyen2().getIdCitoyen();
			}
			else
			{
				id_conjoint = getListMarriage().lastElement().getCitoyen1().getIdCitoyen();
			}
		}
		else
		{
			id_conjoint = -1;
		}
	}
}