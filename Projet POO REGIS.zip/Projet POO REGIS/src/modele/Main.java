package modele;
import java.io.*;
import java.util.*;
import java.util.Date;
import java.io.Serializable;
public class Main implements Serializable
{
	//id de serialisation
	private static final long serialVersionUID = 1L;
	private Mairie mairie_gere;
	public Main()
	{
		mairie_gere = new Mairie();
		
		///Test du modele dans le main
		/// Création de mairie ///
		//Mairie mairie1 = new Mairie(91750,"Champceuil","10 rue Deschamps");
		
		/// Création de citoyen (pas possible car Citoyen est une classe abstraite)///
		//Citoyen citoyen1 = new Citoyen("Regis","Mathis", new Date(), true)

		/// Création d'homme ///
		//Homme homme1 = new Homme("Lefebvre", "Florian", new Date(), mairie1);
		
		///construction avancé
		//Homme homme2 = new Homme(citoyen1);
		
		/// Création de femme ///
		//Femme femme1 = new Femme("Remy","Clara",new Date(),mairie1);
		

		/// Création des marriages ///
		//Marriage marriage1 = new Marriage(new Date(), mairie1, homme1, femme1);

		/// Création des naissances ///
		//Naissance naissance1 = new Naissance(new Date(),homme1,femme1,new Homme("Lefebvre","Baptiste",new Date(),mairie1),mairie1);
		
		/// Création des divorces ///
		//Divorce divorce1 = new Divorce(new Date(), mairie1, marriage1);
		
		/// Création des décès ///
		//Deces deces = new Deces(new Date(), mairie1, homme1);


		/// Utilisation de méthode simple qui compléte le constructeur simple
		
		/// Citoyen
		//citoyen1.setMairie(mairie1);
		//citoyen1.setNaissance(naissance1);
		//citoyen1.setDeces(deces1);
		//citoyen1.getIdCitoyen();
		//citoyen1.getNom();
		//citoyen1.getPrenom();
		//citoyen1.getDateNaissance();
		//citoyen1.getSexe();
		//citoyen1.getMairie();
		//citoyen1.getDeces();
		//citoyen1.getNaissance();
		
		///Mairie 
		//mairie1.addCitoyen(homme1);
		//mairie1.addCitoyen(femme1);
		//mairie1.addDeces(deces1);
		//mairie1.addMarriage(marriage1);
		//mairie1.addNaissance(naissance1);
		//mairie1.addDivorce(divorce1);
		//mairie1.getListCitoyen();
		//mairie1.getListDeces();
		//mairie1.getListDivorce();
		//mairie1.getListMarriage();
		//mairie1.getListNaissance();

		///Naissance
		//naissance1.setMairie(mairie1);
		//naissance1.getCitoyen();
		//naissance1.getPere();
		//naissance1.getMere();
		//naissance1.getDateNaissance();
		//naissance1.getMairie();

		///Marriage
		//marriage1.setMairie(mairie1);
		//marriage1.setDivorce(divorce1);
		//marriage1.setCitoyen1(femme1);
		//marriage1.setCitoyen2(homme1);
		//marriage1.getDateMarriage();
		//marriage1.getCitoyen1();
		//marriage1.getCitoyen2();
		//marriage1.getDivorce();
		//marriage1.getMairie();

		///Divorce
		//divorce1.setMairie(mairie1);
		//divorce1.setMarriage(marriage1);
		//divorce1.getDateDivorce();
		//divorce1.getMarriage();
		//divorce1.getMairie();

		///Deces
		//deces1.setCitoyen(homme1);
		//deces1.setMairie(mairie1);
		//deces1.getDateDeces();
		//deces1.getCitoyen();
		//deces1.getMairie();

		///Homme
		//homme1.addMarriage(marriage1);
		//homme1.addNaissance(naissance1);
		//homme1.getListMarriage();
		//homme1.getListNaissance();

		///Femme
		//femme1.addMarriage(marriage1);
		//femme1.addNaissance(naissance1);
		//femme1.getListMarriage();
		//femme1.getListNaissance();
	}
	public Main(Mairie m)
	{
		mairie_gere = m;
	}
	public Mairie getMairieGere()
	{
		return mairie_gere;
	}
	public void setMairieGere(Mairie m)
	{
		mairie_gere = m;
	}
	public static void main (String[] args)
	{
		Main modele = new Main();
	}

}