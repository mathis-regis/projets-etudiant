package modele;
import java.util.Date;
import java.io.Serializable;


public class Naissance implements Serializable{

	//id de serialisation
	private static final long serialVersionUID = 1L;
    /**
     * Default constructor
     */
    public Naissance() {
    }

    /**
     * 
     */
    private Date Date_naissance;
	
	/// Association ///
	
	private Citoyen pere;
	private Citoyen mere;
	private Citoyen citoyen;
	private Mairie mairie;
	
	/// Constructeur simple ///
	
	public Naissance(Date d)
	{
		Date_naissance = d;
	}
	
	/// Constructeur avancé ///
	
	public Naissance(Date d, Citoyen p, Citoyen m, Citoyen c, Mairie ma)
	{
		Date_naissance = d;
		setPere(p);
		setMere(m);
		setCitoyen(c);
		setMairie(ma);
	}

	/// methode ///
	public void setPere (Citoyen p)
	{
		pere = p;
	}
	public void setMere (Citoyen m)
	{
		mere = m;
	}
	public void setCitoyen (Citoyen c)
	{
		citoyen = c;
	}
	public void setMairie (Mairie m)
	{
		mairie = m;
	}

	public Citoyen getPere()
	{
		return pere;
	}
	public Citoyen getMere()
	{
		return mere;
	}
	public Citoyen getCitoyen()
	{
		return citoyen;
	}
	public Mairie getMairie()
	{
		return mairie;
	}
	public Date getDateNaissance()
	{
		return Date_naissance;
	}
}