package modele;
import java.util.Date;
import java.io.Serializable;


/**
 * 
 */
public class Marriage implements Serializable{

	//id de serialisation
	private static final long serialVersionUID = 1L;
    /**
     * Default constructor
     */
    public Marriage() {
    }

    /**
     * 
     */
    private Date Date_marriage;

	/// Association ///
	
	private Mairie mairie;
	private Citoyen citoyen1;
	private Citoyen citoyen2;
	private Divorce divorce = null;
	
	/// Constructeur simple ///
	public Marriage(Date d)
	{
		Date_marriage = d;
	}
	/// Constructeur avancé ///
	public Marriage(Date d, Mairie m, Citoyen c1, Citoyen c2)
	{
		Date_marriage = d;
		setMairie(m);
		setCitoyen1(c1);
		setCitoyen2(c2);
	}
	/// Methode ///
	public void setMairie(Mairie m)
	{
		mairie = m;
	}
	public void setCitoyen1(Citoyen c1)
	{
		citoyen1 = c1;
	}
	public void setCitoyen2(Citoyen c2)
	{
		citoyen2 = c2;
	}
	public void setDivorce(Divorce d)
	{
		divorce = d;
	}
	public Mairie getMairie()
	{
    return mairie;
	}
	public Citoyen getCitoyen1() 
	{
    	return citoyen1;
	}
	public Citoyen getCitoyen2() 
	{
    	return citoyen2;
	}
	public Divorce getDivorce() 
	{
    	return divorce;
	}
	public Date getDateMarriage()
	{
    	return Date_marriage;
	}
}