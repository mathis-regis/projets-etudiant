package modele;
import java.util.Date;
import java.io.Serializable;
/**
 * 
 */
public class Divorce implements Serializable{

	//id de serialisation
	private static final long serialVersionUID = 1L;
    /**
     * Default constructor
     */
    public Divorce() {
    }
	/**
     * 
     */
    private Date Date_divorce;
	
	/// Association ///
	
	private Mairie mairie;
	private Marriage marriage;
	
	/// Constructeur simple ///
	
	public Divorce(Date d)
	{
		Date_divorce = d;
	}

	/// Constructeur avancé ///
	public Divorce(Date d, Mairie m, Marriage ma)
	{
		Date_divorce = d;
		setMairie(m);
		setMarriage(ma);
	}
	
	/// Méthode ///
	public void setMairie(Mairie m)
	{
		mairie = m;
	}
	public void setMarriage(Marriage m)
	{
		marriage = m;
	}
	
	public Mairie getMairie()
	{
		return mairie;
	}
	public Marriage getMarriage()
	{
		return marriage;
	}
	public Date getDateDivorce()
	{
		return Date_divorce;
	}
}