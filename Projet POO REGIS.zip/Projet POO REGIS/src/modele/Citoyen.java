package modele;
import java.io.*;
import java.util.*;
import java.io.Serializable;
	
	
public abstract class Citoyen implements Serializable{
	
	//id de serialisation
	private static final long serialVersionUID = 1L;

    /**
     * Default constructor
     */
    public Citoyen() {
		ID_Citoyen = compteurID++;
    }

    /**
     * 
     */
    private int ID_Citoyen;
	private static int compteurID = 0;

    /**
     * 
     */
    private String nom;

    /**
     * 
     */
    private String prenom;

    /**
     * 
     */
    private Date Date_naissance;

    /**
     * 
     */
    private boolean sexe;
	
	protected int id_conjoint = -1;

	/// Association ///
	
	Mairie mairie ;
	Naissance naissance;
	Deces deces;
	
	/// Constructeur simple ///
	
	public Citoyen (String n, String p, Date d, boolean s)
	{
		ID_Citoyen = compteurID++;
		nom = n;
		prenom = p;
		Date_naissance = d;
		sexe = s;
	}
	
	/// Constructeur avancé ///
	
	public Citoyen(String n, String p, Date d, boolean s, Mairie m)
	{
		ID_Citoyen = compteurID++;
		nom = n;
		prenom = p;
		Date_naissance = d;
		sexe = s;
		setMairie(m);
	}
	
	
	/// Methode ///
	
	public void setMairie (Mairie m)
	{
		mairie = m;
	}
	public void setNaissance (Naissance n)
	{
		naissance = n;
	}
	public void setDeces (Deces d)
	{
		deces = d;
	}

	public Mairie getMairie ()
	{
		return mairie ;
	}
	public Naissance getNaissance ()
	{
		return naissance ;
	}
	public Deces getDeces ()
	{
		return deces;
	}
	public int getIdCitoyen()
	{
		return ID_Citoyen;
	}
	public String getPrenom()
	{
		return prenom;
	}
	public String getNom()
	{
		return nom;
	}
	public boolean getSexe()
	{
		return sexe;
	}
	public Date getDateNaissance()
	{
		return Date_naissance ;
	}
	public int getIdConjoint()
	{
		return id_conjoint;
	}
	 public abstract boolean estMarie();
	 public abstract void addMarriage(Marriage mar);
	 public abstract void addNaissance(Naissance n);
	 public abstract Vector <Marriage> getListMarriage();
	 public abstract void setIdConjoint();
}