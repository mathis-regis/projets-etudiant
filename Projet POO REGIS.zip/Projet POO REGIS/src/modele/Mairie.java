package modele;
import java.io.*;
import java.util.*;
import java.util.Date;
import java.io.Serializable;
/**
 * 
 */
public class Mairie implements Serializable{
	
	//id de serialisation
	private static final long serialVersionUID = 1L;
	
    /**
     * Default constructor
     */
	 
    public Mairie() {
    }

    /**
     * 
     */
	 
    private int code_postale;

    /**
     * 
     */
    private String nom_ville;

    /**
     * 
     */
    private String adresse_mairie;
	
	/// Association ///
	private Vector <Citoyen> listCitoyen = new Vector <Citoyen>();
	/**
     * 
     */
	private Vector <Marriage> listMarriage = new Vector <Marriage>();
	/**
     * 
     */
	private Vector <Divorce> listDivorce = new Vector <Divorce>();
	 /**
     * 
     */
	 private Vector <Naissance> listNaissance = new Vector <Naissance>();
	 /**
     * 
     */
	 private Vector <Deces> listDeces = new Vector <Deces>();

	/// Constructeur simple ///
	public Mairie(int cp, String nv, String am)
	{
		code_postale = cp;
		nom_ville = nv;
		adresse_mairie = am;
	}
	
	/// Constructeur avancé ///
	public Mairie(int cp, String nv, String am, Citoyen c, Marriage m, Divorce d, Naissance n, Deces de)
	{
		code_postale = cp;
		nom_ville = nv;
		adresse_mairie = am;
		addCitoyen(c);
		addMarriage(m);
		addDivorce(d);
		addNaissance(n);
		addDeces(de);
	}
	
	/// Methode ///
	
	public void addCitoyen (Citoyen c)
	{
		listCitoyen.add(c);
	}
	public void addMarriage (Marriage m)
	{
		listMarriage.add(m);
	}
	public void addDivorce (Divorce d)
	{
		listDivorce.add(d);
	}
	public void addNaissance (Naissance n)
	{
		listNaissance.add(n);
	}
	public void addDeces(Deces d)
	{
		listDeces.add(d);
	}

	public String getNomVille()
	{
		return nom_ville;
	}
	public Vector <Citoyen> getListCitoyen()
	{
		return listCitoyen ;
	}
	public Vector <Marriage> getListMarriage()
	{
		return listMarriage ;
	}
	public Vector <Naissance> getListNaissance()
	{
		return listNaissance ;
	}
	public Vector <Divorce> getListDivorce()
	{
		return listDivorce ;
	}
	public Vector <Deces> getListDeces()
	{
		return listDeces ;
	}

	public Citoyen trouveCitoyen(int id)
	{
		if (getListCitoyen().isEmpty())
		{
			return null;
		}
		else
		{
		int taille = getListCitoyen().size();
		for (int i = 0; i<taille; i++)
		{
			if (getListCitoyen().get(i).getIdCitoyen() == id)
			{
				return getListCitoyen().get(i);
			}
		
		}
		}
		return null;
	}
}