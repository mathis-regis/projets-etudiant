package controleur;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import vue.*;
import modele.*;

public class Controleur_nv_naissance implements ActionListener
{
	JButton bouton;
	ModeleUtiliser mode;
	FenetreNaissance fenetre;
	Accueil accueil;
	
	public Controleur_nv_naissance(JButton btn,ModeleUtiliser md,Accueil a)
	{
		bouton = btn;
		mode = md;
		accueil = a;
		fenetre = new FenetreNaissance(mode,accueil);
		fenetre.setVisible(false);
	}
	public void actionPerformed(ActionEvent e)
	{
		accueil.setVisible(false);
		fenetre.setVisible(true);
		System.out.println("Félicitation vous avez un nouveau membre dans la famille !");
	}
}