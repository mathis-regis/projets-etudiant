package controleur;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.List;
import java.util.ArrayList;
import vue.*;
import modele.*;


public class Controleur_afficher_citoyens implements ActionListener
{
	JButton bouton;
	ModeleUtiliser mode;
	Accueil accueil;
	FenetreAfficher fenetre;
	
	public Controleur_afficher_citoyens(JButton btn,ModeleUtiliser md,Accueil a)
	{
		bouton = btn;
		mode = md;
		accueil = a;
	}
	public void actionPerformed(ActionEvent e)
	{
		//on recupere la mairie
		Mairie mairie = mode.getMain().getMairieGere();
		//on initialise le tableau de retour
		List<String[]> donnee_tableau = new ArrayList<>() ;
		//on intialise le tableau qui représenteras les donnée d'un citoyen a la iéme ittération de la boucle for
		String[] donnee_citoyen;
		//on intialise les variables a utiliser dans la boucle for et qui changeronse de valeurs en fonction du citoyen
		String idStr;
		String dateStr;
		String sexe;
		Citoyen citoyen;
		Marriage marriage;
		Citoyen citoyen_marie;
		String conjoint;
		
		int nb_citoyen_mairie = mairie.getListCitoyen().size();
		System.out.println("NB citoyen " + nb_citoyen_mairie);		
		for (int i = 0; i<nb_citoyen_mairie; i++)
		{
			//on recupere les données du iéme citoyen avec les variables
			citoyen = mairie.getListCitoyen().get(i);
			idStr = citoyen.getIdCitoyen() + "" ;
			dateStr = citoyen.getDateNaissance() + "";
			//on récupére le sexe du iéme citoyen
			if (citoyen.getSexe() == true)
			{
				sexe = "homme";
			}
			else 
			{
				sexe = "femme";
			}
			//on vérifie si le iéme citoyen est marié et si oui on récupére le nom et prénom de son conjoint
			if (citoyen.estMarie())
			{
				marriage = citoyen.getListMarriage().lastElement();
				citoyen_marie = mairie.trouveCitoyen(citoyen.getIdConjoint());
				conjoint = citoyen_marie.getPrenom() + " " + citoyen_marie.getNom();
			}
			else
			{
				 conjoint = "personne";
			}
			donnee_citoyen = new String[] {idStr,citoyen.getPrenom(),citoyen.getNom(),dateStr,sexe,conjoint};
			donnee_tableau.add(donnee_citoyen);
		}
		//on convertit la liste dynamique en String[][] pour FenetreAfficher
		String[][] tableau_retour = donnee_tableau.toArray(new String[donnee_tableau.size()][]);
		fenetre = new FenetreAfficher(mode,accueil,tableau_retour);
		accueil.setVisible(false);
		fenetre.setVisible(true);
		System.out.println("Voici la liste des citoyens de la mairie :");
	}
}