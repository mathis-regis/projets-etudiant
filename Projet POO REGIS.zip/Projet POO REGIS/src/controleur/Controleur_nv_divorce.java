package controleur;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import vue.*;
import modele.*;

public class Controleur_nv_divorce implements ActionListener
{
	JButton bouton;
	ModeleUtiliser mode;
	FenetreDivorce fenetre;
	Accueil accueil;
	
	public Controleur_nv_divorce(JButton btn,ModeleUtiliser md,Accueil a)
	{
		bouton = btn;
		mode = md;
		accueil = a;
		fenetre = new FenetreDivorce(mode,accueil);
		fenetre.setVisible(false);
	}
	public void actionPerformed(ActionEvent e)
	{
		accueil.setVisible(false);
		fenetre.setVisible(true);
		System.out.println("Aie un divorce !");
	}
}