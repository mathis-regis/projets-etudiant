package controleur;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import vue.*;
import modele.*;

public class Controleur_identification_ID implements ActionListener
{
	JButton bouton;
	ModeleUtiliser mode;
	Accueil accueil;
	FenetreIdentification fenetre;
	
	public Controleur_identification_ID(JButton btn,ModeleUtiliser md,Accueil a)
	{
		bouton = btn;
		mode = md;
		accueil = a;
		fenetre = new FenetreIdentification(mode,accueil);
		fenetre.setVisible(false);
	}
	public void actionPerformed(ActionEvent e)
	{
		accueil.setVisible(false);
		fenetre.setVisible(true);
		System.out.println("Haha je t'ai trouvé !");
	}
}