package controleur;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.Date;
import modele.*;
import vue.*;

public class Controleur_EnregistrerNaissance implements ActionListener
{
	//JButton bouton;
	ModeleUtiliser modele;
	JFrame fenetre;
	JFrame fenetre_resultat;
	JTextField IdPere;
	JTextField IdMere;
	JTextField PrenomEnfant;
	JRadioButton garcon;
	JRadioButton fille;
	
	public Controleur_EnregistrerNaissance(ModeleUtiliser mode,JFrame f,JTextField pere,JTextField mere,JTextField prenom,JRadioButton garcon,JRadioButton fille)
	{
		
		modele = mode;
		fenetre = f;
		IdPere = pere;
		IdMere = mere;
		PrenomEnfant = prenom;
		this.garcon = garcon;
		this.fille = fille;
	}
	public void actionPerformed(ActionEvent e)
	{
		int idp = Integer.parseInt(IdPere.getText());
		int idm = Integer.parseInt(IdMere.getText());
		Mairie mairie = modele.getMain().getMairieGere();
		Citoyen pere = mairie.trouveCitoyen(idp);
		Citoyen mere = mairie.trouveCitoyen(idm);
		String prenom = PrenomEnfant.getText().trim();
		//cas ou le pere et la mere sont introuvables dans la mairie
		if ((pere == null)&&(mere == null))
		{
			fenetre_resultat = new FenetreErreur(modele,fenetre,"Les ID ne correspondent a aucun citoyen de la mairie.");
		}
		//cas ou juste le père est introuvable dans la mairie
		else if(pere == null)
		{
			fenetre_resultat = new FenetreErreur(modele,fenetre,"L'ID du père donnée ne correspond a aucun citoyen de la mairie.");
		}
		//cas ou juste la mère est introuvable dans la mairie
		else if(mere == null)
		{
			fenetre_resultat = new FenetreErreur(modele,fenetre,"L'ID de la mère donnée ne correspond a aucun citoyen de la mairie.");
		}
		//cas ou le pere et la mere ne sont pas du bon sexe 
		else if((!(pere instanceof Homme))&& (!(mere instanceof Femme)))
		{
			fenetre_resultat = new FenetreErreur(modele,fenetre,"Le père donnée n'est pas un homme et la mère donnée n'est pas une femme.");
		}
		//cas ou le pere n'est pas un homme
		else if(!(pere instanceof Homme))
		{
			fenetre_resultat = new FenetreErreur(modele,fenetre,"Le père donné n'est pas un homme.");
		}
		//cas ou la mere n'est pas une femme
		else if(!(mere instanceof Femme))
		{
			fenetre_resultat = new FenetreErreur(modele,fenetre,"La mère n'est pas une femme.");
		}
		//cas ou les 2 parents sont morts
		else if ((pere.getDeces() != null)&&(mere.getDeces() != null))
		{
			fenetre_resultat = new FenetreErreur(modele,fenetre,"Les 2 parents sont morts.");
		}
		//cas ou le père est mort
		else if (pere.getDeces() != null)
		{
			fenetre_resultat = new FenetreErreur(modele,fenetre,"Le pere est mort.");
		}
		//cas ou la mère est morte
		else if (mere.getDeces() != null)
		{
			fenetre_resultat = new FenetreErreur(modele,fenetre,"La mère est morte.");
		}
		//cas ou les sexe n'a pas été sélectionné
		else if (!(garcon.isSelected()) && !(fille.isSelected()))
		{
			fenetre_resultat = new FenetreErreur(modele,fenetre,"Le sexe de l'enfant n'a pas été sélectionné.");
		}
		//cas ou aucun prénom est choisie
		else if (prenom.isEmpty())
		{
			fenetre_resultat = new FenetreErreur(modele,fenetre,"Le prénom de l'enfant n'a pas été donné.");
		}
 		//cas ou la naissance peut être effectué
		else
		{
			//on garde le nom de famille du pere pour le donner a l'enfant
			String nomPere = pere.getNom();
			Citoyen enfant;
			//on créé l'enfant
			if (garcon.isSelected())
			{
				enfant = new Homme(nomPere,prenom,new Date(),mairie);
			}
			else
			{
				enfant = new Femme(nomPere,prenom,new Date(),mairie);
			}
			//on créé une Naissance
			Naissance naissance = new Naissance(new Date(),pere,mere,enfant,mairie);
			//on rajoute la Naissance a la mairie,au pere,la mere et l'enfant
			mairie.addNaissance(naissance);
			pere.addNaissance(naissance);
			mere.addNaissance(naissance);
			enfant.addNaissance(naissance);
			//on rajoute l'enfant dans la liste de citoyen de la mairie
			mairie.addCitoyen(enfant);
			//on remplace l'ancienne mairie du modele par la mairie modifié
			modele.getMain().setMairieGere(mairie);
			//on crée la fenetre_resultat pour la naissance réussite
			String message = enfant.getPrenom() + " " + enfant.getNom() + " a bien été enregistré, son identifiant de citoyen est " + enfant.getIdCitoyen() + ".";
			fenetre_resultat = new FenetreReussis(modele,fenetre,message);
			System.out.println("La naissance a bien été enregistré.");
		}
		IdPere.setText("");
		IdMere.setText("");
		PrenomEnfant.setText("");
		fenetre.setVisible(false);
		fenetre_resultat.setVisible(true);
	}
}