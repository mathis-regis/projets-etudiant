package controleur;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.Date;
import java.text.SimpleDateFormat;
import java.text.ParseException;
import modele.*;
import vue.*;

public class Controleur_EnregistrerCitoyen implements ActionListener
{
	ModeleUtiliser modele;
	JFrame fenetre;
	JFrame fenetre_resultat;
	JTextField prenom;
	JTextField nom;
	JTextField date_naissance;
	JRadioButton homme;
	JRadioButton femme;
	
	public Controleur_EnregistrerCitoyen(ModeleUtiliser mode,JFrame f,JTextField prenom,JTextField nom,JTextField date_naissance,JRadioButton homme,JRadioButton femme)
	{
		modele = mode;
		fenetre = f;
		this.prenom = prenom;
		this.nom = nom;
		this.date_naissance = date_naissance;
		this.homme = homme;
		this.femme = femme;
	}
	public void actionPerformed(ActionEvent e)
	{
		fenetre_resultat = null;
		Mairie mairie = modele.getMain().getMairieGere();
		//format simplifier pour récupérer la date entré par l'utilisateur
		SimpleDateFormat format = new SimpleDateFormat("dd/MM/yyyy");
		//on récupére les information rentré par l'utilisateur
		String prenomStr = prenom.getText().trim();
		String nomStr = nom.getText().trim();
		String date_naissanceStr = date_naissance.getText();
		//on met la date entré par l'utilisateur au format Date
		Date date = null;
		try
		{
			date = format.parse(date_naissanceStr);
		}
		catch(ParseException E)
		{
			fenetre_resultat = new FenetreErreur(modele,fenetre,"La date rentré n'est pas au bon format.");
		}
		//on vérifie que l'erreur du format de la date a été traité et si il y a eu erreur on l'affiche
		if (fenetre_resultat != null)
		{
			System.out.println("erreur dans la date");
		}
		else
		{
			//cas ou prenom et nom n'ont pas été renseigné
			if((prenomStr.isEmpty()) && (nomStr.isEmpty()))
			{
				fenetre_resultat = new FenetreErreur(modele,fenetre,"Le prenom et le nom n'ont pas été donné");
			}
			else if (prenomStr.isEmpty())
			{
				fenetre_resultat = new FenetreErreur(modele,fenetre,"Le prenom n'a pas été donné");
			}
			else if (nomStr.isEmpty())
			{
				fenetre_resultat = new FenetreErreur(modele,fenetre,"Le nom n'a pas été donné");
			}
			//cas ou le citoyen peut être crée
			else
			{
				if (homme.isSelected())
				{
					Homme citoyen =new Homme(nomStr,prenomStr,date,mairie);
					String message = citoyen.getPrenom() + " " + citoyen.getNom() + " a bien été enregistré, son identifiant de citoyen est " + citoyen.getIdCitoyen() + ".";
					fenetre_resultat = new FenetreReussis(modele,fenetre,message);
					mairie.addCitoyen(citoyen);
				}
				else 
				{
					Femme citoyen = new Femme(nomStr,prenomStr,date,mairie);
					String message = citoyen.getPrenom() + " " + citoyen.getNom() + " a bien été enregistré, son identifiant de citoyen est " + citoyen.getIdCitoyen() + ".";
					fenetre_resultat = new FenetreReussis(modele,fenetre,message);
					mairie.addCitoyen(citoyen);
				}
				System.out.println("Citoyen bien enregistré");
				
			}
		}
		date_naissance.setText("");
		prenom.setText("");
		nom.setText("");
		modele.getMain().setMairieGere(mairie);
		fenetre.setVisible(false);
		fenetre_resultat.setVisible(true);
		
	}
}