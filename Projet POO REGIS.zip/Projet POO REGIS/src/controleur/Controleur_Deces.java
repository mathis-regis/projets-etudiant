package controleur;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import vue.*;
import modele.*;

public class Controleur_Deces implements ActionListener
{
	JButton bouton;
	ModeleUtiliser mode;
	FenetreDeces fenetre;
	Accueil accueil;
	
	public Controleur_Deces(JButton btn,ModeleUtiliser md,Accueil a)
	{
		bouton = btn;
		mode = md;
		accueil = a;
		fenetre = new FenetreDeces(mode,accueil);
		fenetre.setVisible(false);
	}
	public void actionPerformed(ActionEvent e)
	{
		accueil.setVisible(false);
		fenetre.setVisible(true);
		System.out.println("Mes condoléance pour ce décès");
	}
}