package controleur;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.Date;
import modele.*;
import vue.*;

public class Controleur_RechercheCitoyen implements ActionListener
{
	ModeleUtiliser modele;
	JFrame fenetre;
	JFrame fenetre_resultat;
	JTextField ID;
	
	
	public Controleur_RechercheCitoyen(ModeleUtiliser mode,JFrame f,JTextField id)
	{
		modele = mode;
		fenetre = f;
		ID = id;
	}
	public void actionPerformed(ActionEvent e)
	{
		int num;
		num = Integer.parseInt(ID.getText());
		Mairie mairie = modele.getMain().getMairieGere();
		Citoyen citoyen = mairie.trouveCitoyen(num);
		//cas ou le citoyen n'est pas trouvé dans la mairie
		if(citoyen == null)
		{
			fenetre_resultat = new FenetreErreur(modele,fenetre,"L'ID ne correspond a aucun citoyen de la mairie");
		}
		else
		{
			String prenom = citoyen.getPrenom();
			String nom = citoyen.getNom();
			Date date_naisance = citoyen.getDateNaissance();
			String sexe;
			if (citoyen.estMarie())
			{
				Marriage marriage = citoyen.getListMarriage().lastElement();
				Citoyen citoyen_marie;
				citoyen_marie = mairie.trouveCitoyen(citoyen.getIdConjoint());
				if(citoyen.getSexe() == true)
				{
					sexe = "homme";
				}
				else
				{
					sexe = "femme";
				}
				fenetre_resultat = new FenetreCitoyenTrouve(modele,fenetre,ID.getText(),prenom,nom,date_naisance,sexe,citoyen_marie.getPrenom(),citoyen_marie.getNom());
			}
			else
			{
				if(citoyen.getSexe() == true)
				{
					sexe = "homme";	
				}
				else
				{
					sexe = "femme";	
				}
				fenetre_resultat = new FenetreCitoyenTrouve(modele,fenetre,ID.getText(),prenom,nom,date_naisance,sexe);
			}
		}
		fenetre.setVisible(false);
		fenetre_resultat.setVisible(true);
	}
}