package controleur;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.Date;
import modele.*;
import vue.*;

public class Controleur_EnregistrerDivorce implements ActionListener
{
	ModeleUtiliser modele;
	JFrame fenetre;
	JFrame fenetre_resultat;
	JTextField ID;
	
	
	public Controleur_EnregistrerDivorce(ModeleUtiliser mode,JFrame f,JTextField id)
	{
		modele = mode;
		fenetre = f;
		ID = id;
	}
	public void actionPerformed(ActionEvent e)
	{
		int num;
		num = Integer.parseInt(ID.getText());
		Mairie mairie = modele.getMain().getMairieGere();
		Citoyen citoyen = mairie.trouveCitoyen(num);
		Citoyen citoyen_marie = null;
		Marriage marriage;
		
		//cas ou l'id ne coresspond a aucun citoyen
		if (citoyen == null)
		{
			fenetre_resultat = new FenetreErreur(modele,fenetre,"L'ID données ne correspond a aucun citoyen de la mairie.");
		}
		//cas ou le citoyen n'est pas marié
		else if (citoyen.estMarie() == false)
		{
			fenetre_resultat = new FenetreErreur(modele,fenetre,"Le citoyen n'est pas engagé dans un marriage.");
		}
		//le divorce peut etre effectué
		else
		{
			// on recupere le conjoint
			citoyen_marie = mairie.trouveCitoyen(citoyen.getIdConjoint());
			//on recupere le marriage ici car on est sur que la liste de marriage du citoyen n'est pas nulle
			marriage = citoyen.getListMarriage().lastElement();
			//création du divorce puis ajout du divorce dans le marriage et dans la liste de divorce de la mairie
			Divorce divorce = new Divorce(new Date());
			marriage.setDivorce(divorce);
			mairie.addDivorce(divorce);
			//on met la nouvelle valeur de id_conjoint pour les 2 citoyens
			citoyen.setIdConjoint();
			citoyen_marie.setIdConjoint();
			//on remplace l'ancienne mairie du modele par la mairie modifié
			modele.getMain().setMairieGere(mairie);
			
			fenetre_resultat = new FenetreReussis (modele,fenetre,"Le divorce a bien été enregistré.");
			fenetre_resultat.setVisible(true);
			System.out.println("Le divorce a bien été enregistré.");
		}
		ID.setText("");
		fenetre.setVisible(false);
		fenetre_resultat.setVisible(true);
	}
}