package controleur;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.Date;
import modele.*;
import vue.*;

public class Controleur_EnregistrerDeces implements ActionListener
{
	ModeleUtiliser modele;
	JFrame fenetre;
	JFrame fenetre_resultat;
	JTextField ID;
	
	
	public Controleur_EnregistrerDeces(ModeleUtiliser mode,JFrame f,JTextField id)
	{
		modele = mode;
		fenetre = f;
		ID = id;
	}
	public void actionPerformed(ActionEvent e)
	{
		int num;
		num = Integer.parseInt(ID.getText());
		Mairie mairie = modele.getMain().getMairieGere();
		Citoyen citoyen = mairie.trouveCitoyen(num);
		Citoyen citoyen_marie = null;
		Marriage marriage;
		
		//cas ou l'id ne correspond a aucun citoyen
		if (citoyen == null)
		{
			fenetre_resultat = new FenetreErreur(modele,fenetre,"L'ID données ne correspond a aucun citoyen de la mairie.");
		}
		//cas ou la mort du citoyen a déja été enregistrer
		else if (citoyen.getDeces() != null)
		{
			fenetre_resultat = new FenetreErreur(modele,fenetre,"La mort du citoyen a déja été enregistrée.");
		}
		//cas ou le citoyen n'est pas marié
		else if (citoyen.estMarie() == false)
		{
			fenetre_resultat = new FenetreErreur(modele,fenetre,"Le citoyen n'est pas engagé dans un marriage.");
		}
		//le décés peut être enregistrer
		else
		{
			//si le citoyen est marié on le divorce avant d'enregistrer le décés
			if (citoyen.estMarie())
			{
				// on recupere le conjoint
				citoyen_marie = mairie.trouveCitoyen(citoyen.getIdConjoint());
				//on recupere le marriage ici car on est sur que la liste de marriage du citoyen n'est pas nulle
				marriage = citoyen.getListMarriage().lastElement();
				//création du divorce puis ajout du divorce dans le marriage et dans la liste de divorce de la mairie
				Divorce divorce = new Divorce(new Date());
				marriage.setDivorce(divorce);
				mairie.addDivorce(divorce);
				//on met la nouvelle valeur de id_conjoint pour les 2 citoyens
				citoyen.setIdConjoint();
				citoyen_marie.setIdConjoint();
			}
			//on ajoute le deces au citoyen et a la liste de deces de la mairie
			Deces deces = new Deces(new Date());
			citoyen.setDeces(deces);
			mairie.addDeces(deces);
			//on remplace l'ancienne mairie du modele par la mairie modifié
			modele.getMain().setMairieGere(mairie);
			
			fenetre_resultat = new FenetreReussis (modele,fenetre,"Le décés a bien été enregistré.");
			fenetre_resultat.setVisible(true);
			System.out.println("Le deces a bien été enregistré.");
		}
		ID.setText("");
		fenetre.setVisible(false);
		fenetre_resultat.setVisible(true);
	}
}