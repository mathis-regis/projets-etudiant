package controleur;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import vue.*;
import modele.*;
public class Controleur_retour implements ActionListener
{
	JButton bouton;
	ModeleUtiliser mode;
	JFrame accueil;
	JFrame fenetre;
	public Controleur_retour(JButton b,ModeleUtiliser m, JFrame a,JFrame f)
	{
		bouton = b;
		mode = m;
		accueil = a;
		fenetre = f;
	}
	public void actionPerformed(ActionEvent e)
	{
		fenetre.setVisible(false);
		accueil.setVisible(true);
		System.out.println("retour a la page précédente");
	}
}