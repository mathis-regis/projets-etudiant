package controleur;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.Date;
import modele.*;
import vue.*;

public class Controleur_EnregistrerMarriage implements ActionListener
{
	ModeleUtiliser modele;
	JFrame fenetre;
	JFrame fenetre_resultat;
	JTextField ID1;
	JTextField ID2;
	
	public Controleur_EnregistrerMarriage(ModeleUtiliser mode,JFrame f,JTextField id1, JTextField id2)
	{
		modele = mode;
		fenetre = f;
		ID1 = id1;
		ID2 = id2;
	}
	public void actionPerformed(ActionEvent e)
	{
		int num1;
		int num2;
		num1 = Integer.parseInt(ID1.getText());
		num2 = Integer.parseInt(ID2.getText());
		Mairie mairie = modele.getMain().getMairieGere();
		Citoyen citoyen1 = mairie.trouveCitoyen(num1);
		Citoyen citoyen2 = mairie.trouveCitoyen(num2);
		
		///vérification des condition d'erreur
		//cas ou les 2 ID sont introuvables dans la mairie
		if ((citoyen1 == null) && (citoyen2 ==null))
		{
			fenetre_resultat = new FenetreErreur(modele,fenetre,"Les ID données ne correspondent a aucun citoyen de la mairie.");
			
		}
		//cas ou juste ID1 est introuvable dans la mairie
		else if(citoyen1 == null)
		{
			fenetre_resultat = new FenetreErreur(modele,fenetre,"L'ID1 donnée ne correspond a aucun citoyen de la mairie.");
		}
		//cas ou juste ID2 est introuvable dans la mairie
		else if(citoyen2 == null)
		{
			fenetre_resultat = new FenetreErreur(modele,fenetre,"L'ID2 donnée ne correspond a aucun citoyen de la mairie.");
		}
		//cas ou on veut marier une personne a elle même
		else if(num1 == num2)
		{
			fenetre_resultat = new FenetreErreur(modele,fenetre,"On ne peut pas marier une personne a elle même.");
		}
		//cas ou les deux citoyens sont engagé dans un marriage
		else if ((citoyen1.estMarie() == true)&&(citoyen2.estMarie() == true))
		{
			fenetre_resultat = new FenetreErreur(modele,fenetre,"Les 2 citoyens sont déja engagé dans un marriage.");
		}
		//cas ou le citoyen de l'ID1 est déja engagé dans un marriage
		else if (citoyen1.estMarie() == true)
		{
			fenetre_resultat = new FenetreErreur(modele,fenetre,"Le citoyen de l'ID1 est déja engagé dans un marriage.");
		}
		//cas ou le citoyen de l'ID2 est déja engagé dans un marriage
		else if (citoyen2.estMarie() == true)
		{
			fenetre_resultat = new FenetreErreur(modele,fenetre,"Le citoyen de l'ID2 est déja engagé dans un marriage.");
		}
		//cas ou les deux citoyens sont morts
		else if ((citoyen1.getDeces() != null)&&(citoyen2.getDeces() != null))
		{
			fenetre_resultat = new FenetreErreur(modele,fenetre,"Les 2 citoyens sont morts.");
		}
		//cas ou le citoyen de l'ID1 est mort
		else if (citoyen1.getDeces() != null)
		{
			fenetre_resultat = new FenetreErreur(modele,fenetre,"Le citoyen de l'ID1 est mort.");
		}
		//cas ou le citoyen de l'ID2 est mort
		else if (citoyen2.getDeces() != null)
		{
			fenetre_resultat = new FenetreErreur(modele,fenetre,"Le citoyen de l'ID2 est mort.");
		}
		//aucune erreur dans les données saisie enregistrement
		else
		{
			//Création d'un objet Marriage puis enregistrement du marriage pour le citoyen1,citoyen2 et la mairie qui gere le marriage
			Marriage enregistrement_marriage = new Marriage(new Date(),mairie,citoyen1,citoyen2);
			citoyen1.addMarriage(enregistrement_marriage);
			citoyen2.addMarriage(enregistrement_marriage);
			mairie.addMarriage(enregistrement_marriage);
			//on met la nouvelle valeur de id_conjoint pour les 2 citoyens
			citoyen1.setIdConjoint();
			citoyen2.setIdConjoint();
			//on remplace l'ancienne mairie du modele par la mairie modifié
			modele.getMain().setMairieGere(mairie);
			fenetre_resultat = new FenetreReussis (modele,fenetre,"Le mariage a bien été enregistré Félicitation!");
			System.out.println("Le mariage a bien été enregistré Félicitation!");
		}
		ID1.setText("");
		ID2.setText("");
		fenetre.setVisible(false);
		fenetre_resultat.setVisible(true);
	}
}