package controleur;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
//import com.google.gson.Gson;
import vue.*;
import modele.*;

public class Controleur_quitter implements ActionListener
{
	JButton bouton;
	Accueil accueil;
	ModeleUtiliser modele;
	
	public Controleur_quitter(JButton btn,Accueil a,ModeleUtiliser m)
	{
		bouton = btn;
		accueil = a;
		modele = m;
	}
	public void actionPerformed(ActionEvent e)
	{
		accueil.setVisible(false);
		modele.sauvegarderModele("modele_sauvegarder");
		System.out.println("Au revoir !");
		System.exit(0);
	}
}