package vue;
import modele.*;
import controleur.*;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.Date;

public class FenetreCitoyenTrouve extends JFrame
{
	JTable tableau_fenetre;
	JScrollPane defilement;
	JPanel panneau_centrage;
	JFrame FenetreAvant;
	JButton retour;
	Controleur_retour controleur_retour;
	
	public FenetreCitoyenTrouve (ModeleUtiliser modele,JFrame FenetreAvant,String ID,String prenom,String nom,Date date_naissance,String sexe)
	{
	super(modele.getNomModele() + "(citoyen trouvé)");
	this.getContentPane().setLayout(new BorderLayout());
	//on transforme la date en String
	String dateStr = date_naissance + "";
	//on organise le tableau affichant les données du citoyen
	String[] colonne_tableau ={"ID","Prenom","Nom","Date de naissance","Sexe","Marié à"};
	String[][] donnee_tableau = {{ID,prenom,nom,dateStr,sexe,"personne"}};
	tableau_fenetre = new JTable(new DefaultTableModel(donnee_tableau, colonne_tableau));
	JScrollPane defilement = new JScrollPane(tableau_fenetre);
	//on centre le tableau
	panneau_centrage = new JPanel(new GridLayout(2,1));
	panneau_centrage.add(new JLabel("Citoyen trouvé !", SwingConstants.CENTER));
	panneau_centrage.add(defilement);
	
	
	//bouton de retour
	retour = new JButton("retour");
	controleur_retour = new Controleur_retour(retour,modele,FenetreAvant,this) ;
	retour.addActionListener(controleur_retour);
	
	//ajout des composant
	this.getContentPane().add(panneau_centrage,BorderLayout.CENTER);
	this.getContentPane().add(retour,BorderLayout.SOUTH);
	
	this.setSize(700,700);
	this.setLocationRelativeTo(null);
	}
	public FenetreCitoyenTrouve (ModeleUtiliser modele,JFrame FenetreAvant,String ID,String prenom,String nom,Date date_naissance,String sexe,String prenom_marie,String nom_marie)
	{
	super(modele.getNomModele() + "(citoyen trouvé)");
	this.getContentPane().setLayout(new BorderLayout());
	//on transforme la date en String
	String dateStr = date_naissance + "";
	//on met prenom et nom du conjoint dans un seul string
	String conjoint = prenom_marie + " " + nom_marie;
	//on organise le tableau affichant les données du citoyen
	String[] colonne_tableau ={"ID","Prenom","Nom","Date de naissance","Sexe","Marié à"};
	String[][] donnee_tableau = {{ID,prenom,nom,dateStr,sexe,conjoint}};
	tableau_fenetre = new JTable(new DefaultTableModel(donnee_tableau, colonne_tableau));
	defilement = new JScrollPane(tableau_fenetre);
	//on centre le tableau
	panneau_centrage = new JPanel(new GridLayout(2,1));
	panneau_centrage.add(new JLabel());
	panneau_centrage.add(defilement);
	
	
	//bouton de retour
	retour = new JButton("retour");
	controleur_retour = new Controleur_retour(retour,modele,FenetreAvant,this) ;
	retour.addActionListener(controleur_retour);
	
	//ajout des composant
	this.getContentPane().add(panneau_centrage,BorderLayout.CENTER);
	this.getContentPane().add(retour,BorderLayout.SOUTH);
	
	this.setSize(700,700);
	this.setLocationRelativeTo(null);
	}
}