package vue;
import modele.*;
import controleur.*;
import javax.swing.*;
import java.awt.*;

public class FenetreReussis extends JFrame
{
	JLabel reussis;
	JFrame FenetreAvant;
	JButton retour;
	Controleur_retour controleur_retour;
	
	public FenetreReussis (ModeleUtiliser modele,JFrame FenetreAvant,String TacheReussis)
	{
	super(modele.getNomModele() + "(réussite)");
	
	this.getContentPane().setLayout(new BorderLayout());
	
	reussis = new JLabel("Nouvelle données bien enregistrer : " + TacheReussis);
	
	//bouton de retour
	retour = new JButton("retour");
	controleur_retour = new Controleur_retour(retour,modele,FenetreAvant,this) ;
	retour.addActionListener(controleur_retour);
	
	//ajout des composant
	this.getContentPane().add(reussis,BorderLayout.CENTER);
	this.getContentPane().add(retour,BorderLayout.SOUTH);
	
	this.setSize(700,700);
	this.setLocationRelativeTo(null);
	}
}