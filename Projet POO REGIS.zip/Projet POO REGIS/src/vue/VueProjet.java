package vue;
import modele.*;
import controleur.*;
import javax.swing.*;
import java.awt.*;
import java.io.*;

public class VueProjet
{	
	//fonction de chargement d'un modele
	public static ModeleUtiliser chargerModele(String cheminFichier)
		{
			try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(cheminFichier)))
			{
				System.out.println("modele_sauvegarder existant, chargement...");
				return (ModeleUtiliser) ois.readObject();
			}
			catch (IOException | ClassNotFoundException e)
			{
				System.out.println("pas de modele_sauvegarder création d'un nouveau modele");
				e.printStackTrace();
				return null;
			}
		}
    public static void main (String[] arg)
	{    
		String cheminFichier = "modele_sauvegarder";
		// Charger le modèle existant ou créer un nouveau
		ModeleUtiliser md = chargerModele(cheminFichier);
		if (md == null)
		{
        md = new ModeleUtiliser("Gestion de citoyen");
		}
		Accueil accueil = new Accueil(md);
		accueil.setPreferredSize(new Dimension(700,700));
		accueil.pack();
		accueil.setVisible(true);
    }
}
