package vue;
import modele.*;
import controleur.*;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.Date;
public class FenetreAfficher extends JFrame
	{
		ModeleUtiliser modele;
		JTable tableau_fenetre;
		JScrollPane defilement;
		JLabel texte;
		JButton retour;
		Accueil accueil;
		Controleur_retour controleur_retour;
		public FenetreAfficher(ModeleUtiliser m,Accueil a, String[][] donnee_tableau)
		{
			super(m.getNomModele()+" (affichage de la liste de citoyen)");
			modele = m;
			this.getContentPane().setLayout(new BorderLayout());
			
			texte = new JLabel("Voici la liste des citoyens de la mairie : ", SwingConstants.CENTER);
			//on organise le tableau affichant les données du citoyen
			String[] colonne_tableau ={"ID","Prenom","Nom","Date de naissance","Sexe","Marié à"};
			tableau_fenetre = new JTable(new DefaultTableModel(donnee_tableau, colonne_tableau));
			defilement = new JScrollPane(tableau_fenetre);
			
			
			//gestion bouton de retour
			accueil = a;
			retour = new JButton("retour");
			controleur_retour = new Controleur_retour(retour,modele,accueil,this) ;
			retour.addActionListener(controleur_retour);
			
			this.getContentPane().add(texte,BorderLayout.NORTH);
			this.getContentPane().add(defilement,BorderLayout.CENTER);
			this.getContentPane().add(retour,BorderLayout.SOUTH);
			
			this.setSize(700,700);
			this.setLocationRelativeTo(null);
		}
	}