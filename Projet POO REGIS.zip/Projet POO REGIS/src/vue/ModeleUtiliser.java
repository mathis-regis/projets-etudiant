package vue;
import modele.*;
import controleur.*;
import javax.swing.*;
import java.awt.*;
import java.io.*;
///modele a utiliser pour gerer une mairie
	public class ModeleUtiliser implements Serializable
	{
		//id de serialisation
		private static final long serialVersionUID = 1L;
		private String nom_modele;
		private Main main;
		//création d'un modele avec mairie vide
		public ModeleUtiliser(String n)
		{
			main = new Main();
			nom_modele = n;
		}
		//création d'un modele avec une mairie prédéfinie
		public ModeleUtiliser(String n,Mairie m)
		{
			main = new Main(m);
			nom_modele = n;
		}
		public String getNomModele()
		{
			return nom_modele;
		}
		public Main getMain()
		{
			return main;
		}
		public void setMain(Main m)
		{
			main = m;
		}
		//methode qui sauvegarde un modele
		public void sauvegarderModele(String cheminFichier)
		{
			try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(cheminFichier)))
			{
				oos.writeObject(this);
				System.out.println("Modèle sauvegardé avec succès.");
			}
			catch (IOException e)
			{
			e.printStackTrace();
			}	
		}
	}