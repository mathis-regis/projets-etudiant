package vue;
import modele.*;
import controleur.*;
import javax.swing.*;
import java.awt.*;
public class FenetreDivorce extends JFrame
	{
		ModeleUtiliser modele;
		JPanel panneau;
		JLabel texte;
		JTextField ecriture;
		JButton retour;
		JButton divorcer;
		Accueil accueil;
		Controleur_retour controleur_retour;
		Controleur_EnregistrerDivorce controleur_enregistrer_divorce;
		public FenetreDivorce(ModeleUtiliser m,Accueil a)
		{
			super(m.getNomModele()+" (ajout d'un divorce)");
			modele = m;
			this.getContentPane().setLayout(new GridLayout(3,1));
			
			panneau = new JPanel();
			panneau.setLayout(new GridLayout(1,2));
			
			texte = new JLabel("ID de la personne a divorcer :", SwingConstants.CENTER);
			panneau.add(texte);
			
			ecriture = new JTextField();
			panneau.add(ecriture);
			
			divorcer = new JButton("divorcer");
			
			//gestion bouton de retour
			accueil = a;
			retour = new JButton("retour");
			controleur_retour = new Controleur_retour(retour,modele,accueil,this) ;
			retour.addActionListener(controleur_retour);
			
			//gestion bouton de divorce
			controleur_enregistrer_divorce = new Controleur_EnregistrerDivorce(modele,this,ecriture);
			divorcer.addActionListener(controleur_enregistrer_divorce);
			
			this.getContentPane().add(panneau);
			this.getContentPane().add(divorcer);
			this.getContentPane().add(retour,BorderLayout.SOUTH);
			
			this.setSize(700,700);
			this.setLocationRelativeTo(null);
		}
	}