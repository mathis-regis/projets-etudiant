package vue;
import modele.*;
import controleur.*;
import javax.swing.*;
import java.awt.*;
public class FenetreIdentification extends JFrame
	{
		ModeleUtiliser modele;
		JPanel panneau_ID;
		JLabel ID;
		JTextField ID_enregistrer;
		JButton recherche;
		JButton retour;
		Accueil accueil;
		Controleur_retour controleur_retour;
		Controleur_RechercheCitoyen recherche_citoyen;
		public FenetreIdentification(ModeleUtiliser m,Accueil a)
		{
			super(m.getNomModele()+" (trouver une personne)");
			modele = m;
			this.getContentPane().setLayout(new GridLayout(3,1));
			
			ID = new JLabel("Entrez l'ID du citoyen recherché :", SwingConstants.CENTER);
			ID_enregistrer = new JTextField();
			recherche = new JButton("recherche");
			//gestion du panneau pour l'id
			panneau_ID = new JPanel(new GridLayout(1,2));
			panneau_ID.add(ID);
			panneau_ID.add(ID_enregistrer);
			//gestion du bouton de retour
			accueil = a;
			retour = new JButton("retour");
			controleur_retour = new Controleur_retour(retour,modele,accueil,this) ;
			retour.addActionListener(controleur_retour);
			//gestion du bouton de recherche
			recherche_citoyen = new Controleur_RechercheCitoyen(modele,this,ID_enregistrer);
			recherche.addActionListener(recherche_citoyen);
			
			//ajout des composants dans la vue
			this.getContentPane().add(panneau_ID);
			this.getContentPane().add(recherche);
			this.getContentPane().add(retour);
			
			this.setSize(700,700);
			this.setLocationRelativeTo(null);
		}
	}