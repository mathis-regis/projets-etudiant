package vue;
import modele.*;
import controleur.*;
import javax.swing.*;
import java.awt.*;
public class FenetreMarriage extends JFrame
	{
		ModeleUtiliser modele;
		JLabel ID_marie1;
		JLabel ID_marie2;
		JTextField ID1;
		JTextField ID2;
		JButton marriage;
		JPanel panneau;
		JButton retour;
		Accueil accueil;
		Controleur_retour controleur_retour;
		Controleur_EnregistrerMarriage controleur_enregistrer_marriage;
		public FenetreMarriage(ModeleUtiliser m,Accueil a)
		{
			super(m.getNomModele()+" (ajout d'un mariage)");
			modele = m;
			this.getContentPane().setLayout(new GridLayout(3,1));
			
			marriage = new JButton("Enregistrer le mariage");
			//parametre marriage
			panneau = new JPanel(new GridLayout(2,2));
			ID_marie1 = new JLabel("Entrer l'ID du premier marié  :", SwingConstants.CENTER);
			ID_marie2 = new JLabel("Entrer l'ID du deuxième marié :", SwingConstants.CENTER);
			ID1 = new JTextField();
			ID2 = new JTextField();
			panneau.add(ID_marie1);
			panneau.add(ID1);
			panneau.add(ID_marie2);
			panneau.add(ID2);
			
			
			//gestion bouton de retour
			accueil = a;
			retour = new JButton("retour");
			controleur_retour = new Controleur_retour(retour,modele,accueil,this) ;
			retour.addActionListener(controleur_retour);
			
			// gestion bouton pour enregistrer le marriage
			controleur_enregistrer_marriage = new Controleur_EnregistrerMarriage(modele,this,ID1,ID2);
			marriage.addActionListener(controleur_enregistrer_marriage);
			
			
			//ajout des composants a la vue
			this.getContentPane().add(panneau);
			this.getContentPane().add(marriage);
			this.getContentPane().add(retour);
			
			this.setSize(700,700);
			this.setLocationRelativeTo(null);
		}
	}