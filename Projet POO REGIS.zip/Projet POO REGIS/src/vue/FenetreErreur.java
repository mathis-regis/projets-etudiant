package vue;
import modele.*;
import controleur.*;
import javax.swing.*;
import java.awt.*;

public class FenetreErreur extends JFrame
{
	JLabel erreur;
	JFrame FenetreAvant;
	JButton retour;
	Controleur_retour controleur_retour;
	
	public FenetreErreur (ModeleUtiliser modele,JFrame FenetreAvant,String ErreurDeRetour)
	{
	super(modele.getNomModele() + "(erreur)");
	
	this.getContentPane().setLayout(new BorderLayout());
	
	erreur = new JLabel	("Erreur pendant l'éxécution : " + ErreurDeRetour);
	
	//bouton de retour
	retour = new JButton("retour");
	controleur_retour = new Controleur_retour(retour,modele,FenetreAvant,this) ;
	retour.addActionListener(controleur_retour);
	
	//ajout des composant
	this.getContentPane().add(erreur,BorderLayout.CENTER);
	this.getContentPane().add(retour,BorderLayout.SOUTH);
	
	this.setSize(700,700);
	this.setLocationRelativeTo(null);
	}
}