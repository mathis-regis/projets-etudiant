package vue;
import modele.*;
import controleur.*;
import javax.swing.*;
import java.awt.*;

public class Accueil extends JFrame
	{
		///importation du modele
		ModeleUtiliser mode;
		///declaration de tout les composants
		JLabel que_faire;
		JPanel centrage_texte;
		JButton nv_marriage;
		JButton nv_divorce;
		JButton nv_naissance;
		JButton nv_deces;
		JButton identification_personne;
		JButton afficher_citoyens;
		JButton nv_citoyen;
		JButton quitter;
		///Creéation des controleurs
		Controleur_nv_marriage btn_marriage;
		Controleur_nv_divorce btn_divorce;
		Controleur_nv_naissance btn_naissance;
		Controleur_Deces btn_deces;
		Controleur_identification_ID btn_identification;
		Controleur_afficher_citoyens btn_afficher;
		Controleur_nv_citoyen btn_citoyen;
		Controleur_quitter btn_quitter;
		///
		///Fenetre d'Accueil
		public Accueil(ModeleUtiliser m)
		{
			super(m.getNomModele());
			mode = m;
			
			this.getContentPane().setLayout(new GridLayout(9,1));
			
			///affectation de valeur au composants 
			///texte
			que_faire = new JLabel("Bonjour que voulez vous faire ?");
			///centrage de que_faire
			centrage_texte = new JPanel(new FlowLayout(FlowLayout.CENTER));
			centrage_texte.add(que_faire);
			
			
			///boutons
			nv_marriage = new JButton("1. Mariage");
			nv_divorce = new JButton("2. Divorce");
			nv_naissance = new JButton("3. Naissance");
			nv_deces = new JButton("4. Décés");
			identification_personne = new JButton("5. État d'une personne");
			afficher_citoyens = new JButton("6. Affichage de la liste des personnes ");
			nv_citoyen = new JButton("7. Saisie des personnes");
			quitter = new JButton("8. Quitter le programme");
			
			///controleur des boutons
			//marriage
			btn_marriage = new Controleur_nv_marriage(nv_marriage,mode,this);
			nv_marriage.addActionListener(btn_marriage);
			//divorce
			btn_divorce = new Controleur_nv_divorce(nv_divorce,mode,this);
			nv_divorce.addActionListener(btn_divorce);
			//naissance
			btn_naissance = new Controleur_nv_naissance(nv_naissance,mode,this);
			nv_naissance.addActionListener(btn_naissance);
			//deces
			btn_deces = new Controleur_Deces(nv_deces,mode,this);
			nv_deces.addActionListener(btn_deces);
			//identification avec ID
			btn_identification = new Controleur_identification_ID(identification_personne,mode,this);
			identification_personne.addActionListener(btn_identification);
			//afficher la liste de citoyen
			btn_afficher = new Controleur_afficher_citoyens(afficher_citoyens,mode,this);
			afficher_citoyens.addActionListener(btn_afficher);
			//ajouter un nouveau citoyen 
			btn_citoyen = new Controleur_nv_citoyen(nv_citoyen,mode,this);
			nv_citoyen.addActionListener(btn_citoyen);
			//sauvegarde des changements de données puis quitter
			btn_quitter = new Controleur_quitter(quitter,this,mode);
			quitter.addActionListener(btn_quitter);
			
			///ajout des composants dans la vue
			this.getContentPane().add(centrage_texte);
			this.getContentPane().add(nv_marriage);
			this.getContentPane().add(nv_divorce);
			this.getContentPane().add(nv_naissance);
			this.getContentPane().add(nv_deces);
			this.getContentPane().add(identification_personne);
			this.getContentPane().add(afficher_citoyens);
			this.getContentPane().add(nv_citoyen);
			this.getContentPane().add(quitter);
			
			///taille et position de la fenetre
			this.setSize(700,700);
			this.setLocationRelativeTo(null);
		}
	}