package vue;
import modele.*;
import controleur.*;
import javax.swing.*;
import java.awt.*;
public class FenetreDeces extends JFrame
	{
		ModeleUtiliser modele;
		JPanel panneau;
		JLabel texte;
		JTextField ecriture;
		JButton retour;
		JButton deces;
		Accueil accueil;
		Controleur_retour controleur_retour;
		Controleur_EnregistrerDeces controleur_enregistrer_deces;
		//Controleur_EnregistrerDivorce controleur_enregistrer_deces;
		public FenetreDeces(ModeleUtiliser m,Accueil a)
		{
			super(m.getNomModele()+" (ajout d'un décés)");
			modele = m;
			this.getContentPane().setLayout(new GridLayout(3,1));
			
			panneau = new JPanel();
			panneau.setLayout(new GridLayout(1,2));
			
			texte = new JLabel("ID de la personne décédé :", SwingConstants.CENTER);
			panneau.add(texte);
			
			ecriture = new JTextField();
			panneau.add(ecriture);
			
			deces = new JButton("enregistrer le décés");
			
			//gestion bouton de retour
			accueil = a;
			retour = new JButton("retour");
			controleur_retour = new Controleur_retour(retour,modele,accueil,this) ;
			retour.addActionListener(controleur_retour);
			
			//gestion bouton de deces
			controleur_enregistrer_deces = new Controleur_EnregistrerDeces(modele,this,ecriture);
			deces.addActionListener(controleur_enregistrer_deces);
			
			this.getContentPane().add(panneau);
			this.getContentPane().add(deces);
			this.getContentPane().add(retour,BorderLayout.SOUTH);
			
			this.setSize(700,700);
			this.setLocationRelativeTo(null);
		}
	}