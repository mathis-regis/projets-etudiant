package vue;
import modele.*;
import controleur.*;
import javax.swing.*;
import java.awt.*;

public class FenetreCitoyen extends JFrame
	{
		ModeleUtiliser modele;
		JLabel prenom;
		JTextField ecriture_prenom;
		JLabel nom;
		JTextField ecriture_nom;
		JLabel date_naissance;
		JTextField ecriture_date;
		JLabel sexe;
		ButtonGroup choix_sexe;
		JRadioButton homme;
		JRadioButton femme;
		JPanel panneau_bouton;
		JButton citoyen;
		JButton retour;
		Accueil accueil;
		Controleur_retour controleur_retour;
		Controleur_EnregistrerCitoyen controleur_enregistrer_citoyen;
		public FenetreCitoyen(ModeleUtiliser m,Accueil a)
		{
			super(m.getNomModele()+" (enregistrement de citoyen)");
			modele = m;
			this.getContentPane().setLayout(new GridLayout(5,2));
			panneau_bouton = new JPanel(new GridLayout(1,2));
			//Création des composants
			prenom = new JLabel("Prenom : ", SwingConstants.CENTER);
			ecriture_prenom = new JTextField();
			nom = new JLabel("Nom : ", SwingConstants.CENTER);
			ecriture_nom = new JTextField();
			JLabel date_naissance = new JLabel("Date de naissance format (dd/MM/yyyy):", SwingConstants.CENTER);
			ecriture_date = new JTextField();
			sexe = new JLabel("Sexe : ", SwingConstants.CENTER);
			homme = new JRadioButton("homme");
			femme = new JRadioButton("femme");
			choix_sexe = new ButtonGroup();
			choix_sexe.add(homme);
			choix_sexe.add(femme);
			citoyen = new JButton("Ajouter le citoyen");
			
			
			//gestion bouton de retour
			accueil = a;
			retour = new JButton("retour");
			controleur_retour = new Controleur_retour(retour,modele,accueil,this) ;
			retour.addActionListener(controleur_retour);
			//gestion bouton pour rajouter un citoyen
			controleur_enregistrer_citoyen = new Controleur_EnregistrerCitoyen(modele,this,ecriture_prenom,ecriture_nom,ecriture_date,homme,femme);
			citoyen.addActionListener(controleur_enregistrer_citoyen);
			
			//ajout des composants a la vue
			panneau_bouton.add(homme);
			panneau_bouton.add(femme);
			this.getContentPane().add(prenom);
			this.getContentPane().add(ecriture_prenom);
			this.getContentPane().add(nom);
			this.getContentPane().add(ecriture_nom);
			this.getContentPane().add(date_naissance);
			this.getContentPane().add(ecriture_date);
			this.getContentPane().add(sexe);
			this.getContentPane().add(panneau_bouton);
			this.getContentPane().add(citoyen);
			this.getContentPane().add(retour);
			
			this.setSize(700,700);
			this.setLocationRelativeTo(null);
		}
	}