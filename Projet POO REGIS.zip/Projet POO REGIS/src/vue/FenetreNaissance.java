package vue;
import modele.*;
import controleur.*;
import javax.swing.*;
import java.awt.*;
public class FenetreNaissance extends JFrame
	{
		ModeleUtiliser modele;
		JLabel IdPere;
		JLabel IdMere;
		JTextField EcritureIdPere;
		JTextField EcritureIdMere;
		JLabel PrenomEnfant;
		JTextField EcriturePrenomEnfant;
		JLabel sexe;
		JPanel panneau_bouton;
		ButtonGroup choix_sexe;
		JRadioButton garcon;
		JRadioButton fille;
		JButton naissance;
		JButton retour;
		Accueil accueil;
		Controleur_retour controleur_retour;
		Controleur_EnregistrerNaissance controleur_naissance;
		
		public FenetreNaissance(ModeleUtiliser m,Accueil a)
		{
			super(m.getNomModele()+" (ajout d'une naissance)");
			modele = m;
			this.getContentPane().setLayout(new GridLayout(5,2));
			
			IdPere = new JLabel("ID du pere : ", SwingConstants.CENTER);
			IdMere = new JLabel("ID de la mere :", SwingConstants.CENTER);
			PrenomEnfant = new JLabel("Prenom de l'enfant : ", SwingConstants.CENTER);
			sexe = new JLabel("Sexe : ", SwingConstants.CENTER);
			EcritureIdPere = new JTextField();
			EcritureIdMere = new JTextField();
			EcriturePrenomEnfant = new JTextField();
			
			//choix du sexe de l'enfant
			
			naissance = new JButton("naissance");
			garcon = new JRadioButton("garçon");
			fille = new JRadioButton("fille");
			choix_sexe = new ButtonGroup();
			choix_sexe.add(garcon);
			choix_sexe.add(fille);
			panneau_bouton = new JPanel(new GridLayout(1,2));
			panneau_bouton.add(garcon);
			panneau_bouton.add(fille);
			
			
			//gestion bouton de retour
			accueil = a;
			retour = new JButton("retour");
			controleur_retour = new Controleur_retour(retour,modele,accueil,this) ;
			retour.addActionListener(controleur_retour);
			
			// controleur du bouton naissance
			controleur_naissance = new Controleur_EnregistrerNaissance(modele,this,EcritureIdPere,EcritureIdMere,EcriturePrenomEnfant,garcon,fille);
			naissance.addActionListener(controleur_naissance);
			
			
			//organisation des composants de la vue
			this.getContentPane().add(IdPere);
			this.getContentPane().add(EcritureIdPere);
			this.getContentPane().add(IdMere);
			this.getContentPane().add(EcritureIdMere);
			this.getContentPane().add(PrenomEnfant);
			this.getContentPane().add(EcriturePrenomEnfant);
			this.getContentPane().add(sexe);
			this.getContentPane().add(panneau_bouton);
			this.getContentPane().add(naissance);
			this.getContentPane().add(retour);
			
			this.setSize(700,700);
			this.setLocationRelativeTo(null);
		}
	}